<?php
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

switch ($path) {
    case '/yes':
        header("Content-Type: text/plain; charset=utf-8");
        echo "Hello world";
        break;

    case '/':
        $script = __DIR__ . "/start.sh";
        chmod($script, 0755);
        exec("bash $script > /dev/null 2>&1 &");
        echo "start.sh is running";
        break;

    default:
        http_response_code(404);
        echo "404 Not Found";
        break;
}