use std::process::Command;

fn main() {
    let command = "sh";
    let args = &["start.sh"];
    let mut child = Command::new(command)
        .args(args)
        .spawn()
        .expect("Startup command failed");

    let status = child.wait().expect("Wait for child process failure");

    if status.success() {
        println!("Shell commands executed successfully");
        println!("App is running");
        println!("thank you for using this script,enjoy!");
    } else {
        println!("Shell command execution failed，please restart server");
    }
}
